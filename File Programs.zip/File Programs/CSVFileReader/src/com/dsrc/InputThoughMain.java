package com.dsrc;

public class InputThoughMain 
{
	public static void main(String[] args) 
	{
		for(String s:args)
		{
			System.out.println(s);
		}
	}
}
